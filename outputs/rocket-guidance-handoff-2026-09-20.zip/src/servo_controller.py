"""Calibrated, bounded MAVLink control for the four grid-fin servos."""

import time


NEUTRAL = {7: 1505, 8: 1460, 9: 1370, 10: 1200}
TESTED_OFFSET_US = 200


def validate_bench_cap(max_offset):
    if max_offset not in (200, 300, 400):
        raise ValueError("Bench offset must be 200, 300, or 400 µs")


def expected_settings():
    return {
        7: {"function": 0, "min": 1105, "max": 1905, "trim": 1505},
        8: {"function": 0, "min": 1060, "max": 1860, "trim": 1460},
        9: {"function": 0, "min": 970, "max": 1770, "trim": 1370},
        10: {"function": 0, "min": 800, "max": 1600, "trim": 1200},
    }


def validate_settings(settings):
    for channel, expected in expected_settings().items():
        actual = settings.get(channel)
        if actual is None:
            raise ValueError(f"S{channel} settings were not received")
        for field, expected_value in expected.items():
            if int(actual[field]) != expected_value:
                raise ValueError(
                    f"S{channel} {field} is {int(actual[field])}; "
                    f"expected {expected_value}")


def validate_command(pulses, settings, max_offset):
    validate_bench_cap(max_offset)
    if set(pulses) != set(NEUTRAL):
        raise ValueError("All four fin commands are required")
    for channel, pulse in pulses.items():
        if abs(pulse - NEUTRAL[channel]) > max_offset:
            raise ValueError(f"S{channel} command exceeds the selected offset")
        if not settings[channel]["min"] <= pulse <= settings[channel]["max"]:
            raise ValueError(f"S{channel} command exceeds a saved servo limit")


def pulses_for(decision):
    """Map image-space nose direction to the recorded paired-fin signs."""
    x, y = decision.safe_nose_x_us, decision.safe_nose_y_us
    return {
        7: round(NEUTRAL[7] + y),
        8: round(NEUTRAL[8] - x),
        9: round(NEUTRAL[9] + x),
        10: round(NEUTRAL[10] - y),
    }


def bounded_pulses_for(decision, settings):
    """Scale both steering axes together to fit every saved servo limit."""
    requested = pulses_for(decision)
    scale = 1.0
    for channel, pulse in requested.items():
        offset = pulse - NEUTRAL[channel]
        if offset > 0:
            scale = min(scale, (settings[channel]["max"] - NEUTRAL[channel]) / offset)
        elif offset < 0:
            scale = min(scale, (settings[channel]["min"] - NEUTRAL[channel]) / offset)
    scale = max(0.0, min(1.0, scale))
    return {
        channel: round(NEUTRAL[channel] + (pulse - NEUTRAL[channel]) * scale)
        for channel, pulse in requested.items()
    }


class MavlinkServoController:
    def __init__(self, port, baud, max_offset=400, *, connection=None,
                 mavutil_module=None, clock=time.monotonic,
                 require_disarmed=False):
        if mavutil_module is None:
            from pymavlink import mavutil as mavutil_module
        self.mavutil = mavutil_module
        self.port = port
        self.baud = baud
        self.max_offset = max_offset
        self.connection = connection
        self.clock = clock
        self.require_disarmed = require_disarmed
        self.settings = None
        self.armed = False
        self.last_heartbeat_at = None
        self.last_param_check_at = None
        self.connected = False

    def connect(self):
        validate_bench_cap(self.max_offset)
        if self.connection is None:
            self.connection = self.mavutil.mavlink_connection(
                self.port, baud=self.baud, source_system=251)
        heartbeat = self.connection.wait_heartbeat(timeout=8)
        if heartbeat is None:
            raise RuntimeError("No ArduPilot heartbeat")
        self._note_heartbeat(heartbeat)
        self.settings = self._read_settings()
        validate_settings(self.settings)
        self.last_param_check_at = self.clock()
        self.connected = True
        return self

    def _note_heartbeat(self, heartbeat):
        self.armed = bool(
            heartbeat.base_mode &
            self.mavutil.mavlink.MAV_MODE_FLAG_SAFETY_ARMED)
        self.last_heartbeat_at = self.clock()
        if self.require_disarmed and self.armed:
            raise RuntimeError("Flight controller is armed; stopping bench simulation")

    def _read_param(self, name):
        self.connection.mav.param_request_read_send(
            self.connection.target_system, 1, name.encode("ascii"), -1)
        deadline = self.clock() + 2
        while self.clock() < deadline:
            msg = self.connection.recv_match(blocking=True, timeout=0.2)
            if msg and msg.get_type() == "HEARTBEAT":
                self._note_heartbeat(msg)
            if msg and msg.get_type() == "PARAM_VALUE":
                if str(msg.param_id).rstrip("\x00") == name:
                    return msg.param_value
        raise RuntimeError(f"No response for {name}")

    def _read_settings(self):
        return {
            channel: {
                field: self._read_param(f"SERVO{channel}_{field.upper()}")
                for field in ("function", "min", "max", "trim")
            }
            for channel in NEUTRAL
        }

    def _wait_servo_ack(self, channel):
        deadline = self.clock() + 2
        while self.clock() < deadline:
            msg = self.connection.recv_match(blocking=True, timeout=0.2)
            if msg and msg.get_type() == "HEARTBEAT":
                self._note_heartbeat(msg)
            if msg and msg.get_type() == "COMMAND_ACK":
                if msg.command == self.mavutil.mavlink.MAV_CMD_DO_SET_SERVO:
                    if msg.result != self.mavutil.mavlink.MAV_RESULT_ACCEPTED:
                        raise RuntimeError(f"S{channel} command rejected: {msg.result}")
                    return
        raise RuntimeError(f"No servo ACK for S{channel}")

    def send_cycle(self, pulses, now=None):
        if not self.connected:
            raise RuntimeError("Servo controller is not connected")
        validate_command(pulses, self.settings, self.max_offset)
        for channel, pwm in pulses.items():
            self.connection.mav.command_long_send(
                self.connection.target_system, 1,
                self.mavutil.mavlink.MAV_CMD_DO_SET_SERVO, 0,
                channel, pwm, 0, 0, 0, 0, 0)
            self._wait_servo_ack(channel)

    send = send_cycle

    def _drain_heartbeats(self):
        while True:
            msg = self.connection.recv_match(blocking=False)
            if msg is None:
                return
            if msg.get_type() == "HEARTBEAT":
                self._note_heartbeat(msg)

    def check_health(self, now=None):
        if not self.connected:
            raise RuntimeError("Servo controller is not connected")
        now = self.clock() if now is None else now
        self._drain_heartbeats()
        if self.last_heartbeat_at is None or now - self.last_heartbeat_at > 1.0:
            raise RuntimeError("Flight-controller heartbeat is stale")
        if now - self.last_param_check_at >= 10.0:
            settings = self._read_settings()
            validate_settings(settings)
            self.settings = settings
            self.last_param_check_at = now

    def neutral(self):
        self.send_cycle(NEUTRAL)

    def close(self):
        if self.connection is None:
            return
        try:
            if self.connected:
                try:
                    self.neutral()
                except Exception:
                    pass
        finally:
            self.connection.close()
            self.connected = False


class ServoLink(MavlinkServoController):
    """Backwards-compatible, disarmed-only controller for bench tools."""
    def __init__(self, port, baud, max_offset):
        super().__init__(port, baud, max_offset, require_disarmed=True)
        self.connect()
