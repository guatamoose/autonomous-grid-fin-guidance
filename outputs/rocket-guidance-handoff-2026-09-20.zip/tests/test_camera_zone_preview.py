import sys
import unittest
from pathlib import Path
from unittest.mock import patch

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
from camera_zone_preview import overlay_zones


class PreviewTests(unittest.TestCase):
    def test_explicit_missing_detection_does_not_repeat_detection(self):
        frame = np.zeros((480, 640, 3), dtype=np.uint8)
        with patch("camera_zone_preview.detect_orange_pad",
                   side_effect=AssertionError("detector ran twice")):
            image = overlay_zones(frame, detection=None)
        self.assertEqual(image.size, (640, 480))


if __name__ == "__main__":
    unittest.main()
