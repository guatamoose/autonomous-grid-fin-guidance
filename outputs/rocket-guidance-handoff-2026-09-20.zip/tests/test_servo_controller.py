import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from camera_zones import decide
from servo_controller import (NEUTRAL, MavlinkServoController,
                              bounded_pulses_for, expected_settings)


class FakeMavlink:
    MAV_MODE_FLAG_SAFETY_ARMED = 128
    MAV_CMD_DO_SET_SERVO = 183
    MAV_RESULT_ACCEPTED = 0


class FakeMavutil:
    mavlink = FakeMavlink


class FakeMessage:
    def __init__(self, kind, **values):
        self.kind = kind
        self.__dict__.update(values)

    def get_type(self):
        return self.kind


class FakeConnection:
    target_system = 1

    def __init__(self, parameters=None, armed=False, reject_channel=None):
        self.parameters = parameters or flat_settings()
        self.armed = armed
        self.reject_channel = reject_channel
        self.pending = []
        self.nonblocking = []
        self.events = []
        self.mav = self

    def wait_heartbeat(self, timeout):
        self.events.append(("wait_heartbeat", timeout))
        return FakeMessage("HEARTBEAT", base_mode=(128 if self.armed else 0))

    def param_request_read_send(self, target_system, component, name, index):
        key = name.decode("ascii")
        self.events.append(("param", key))
        self.pending.append(FakeMessage("PARAM_VALUE", param_id=key,
                                        param_value=self.parameters[key]))

    def command_long_send(self, target_system, component, command,
                          confirmation, channel, pwm, *unused):
        self.events.append(("command", int(channel), int(pwm)))
        result = 1 if channel == self.reject_channel else 0
        self.pending.append(FakeMessage("COMMAND_ACK", command=command,
                                        result=result))

    def recv_match(self, blocking=False, timeout=None):
        if self.pending:
            return self.pending.pop(0)
        if not blocking and self.nonblocking:
            return self.nonblocking.pop(0)
        return None

    def close(self):
        self.events.append(("close",))


class FakeClock:
    def __init__(self, now=0.0):
        self.now = now

    def __call__(self):
        return self.now


def flat_settings():
    values = {}
    for channel, setting in expected_settings().items():
        for field, value in setting.items():
            values[f"SERVO{channel}_{field.upper()}"] = value
    return values


def connected_controller(connection=None, clock=lambda: 0.0,
                         require_disarmed=False):
    connection = connection or FakeConnection()
    controller = MavlinkServoController(
        "fake", 57600, 400, connection=connection,
        mavutil_module=FakeMavutil, clock=clock,
        require_disarmed=require_disarmed)
    controller.connect()
    return controller


class ServoControllerTests(unittest.TestCase):
    def test_connect_reads_exact_saved_settings(self):
        controller = connected_controller()
        self.assertEqual(controller.settings, expected_settings())

    def test_autonomous_connection_allows_armed_heartbeat(self):
        controller = connected_controller(FakeConnection(armed=True))
        self.assertTrue(controller.armed)

    def test_bench_connection_rejects_armed_heartbeat(self):
        with self.assertRaisesRegex(RuntimeError, "armed"):
            connected_controller(FakeConnection(armed=True),
                                 require_disarmed=True)

    def test_send_cycle_sends_all_four_validated_commands(self):
        connection = FakeConnection()
        controller = connected_controller(connection)
        before = len(connection.events)
        controller.send_cycle(NEUTRAL, now=0.1)
        commands = [event for event in connection.events[before:]
                    if event[0] == "command"]
        self.assertEqual(commands, [
            ("command", 7, 1505), ("command", 8, 1460),
            ("command", 9, 1370), ("command", 10, 1200)])

    def test_rejected_servo_ack_raises(self):
        controller = connected_controller(FakeConnection(reject_channel=9))
        with self.assertRaisesRegex(RuntimeError, "S9 command rejected"):
            controller.send_cycle(NEUTRAL, now=0.1)

    def test_heartbeat_older_than_one_second_fails_health_check(self):
        controller = connected_controller()
        with self.assertRaisesRegex(RuntimeError, "heartbeat"):
            controller.check_health(now=1.01)

    def test_periodic_parameter_change_fails_health_check(self):
        connection = FakeConnection()
        clock = FakeClock()
        controller = connected_controller(connection, clock=clock)
        connection.parameters["SERVO10_TRIM"] = 1210
        clock.now = 10.1
        connection.nonblocking.append(FakeMessage("HEARTBEAT", base_mode=0))
        with self.assertRaisesRegex(ValueError, "S10"):
            controller.check_health(now=10.1)

    def test_close_attempts_neutral_before_serial_close(self):
        connection = FakeConnection()
        controller = connected_controller(connection)
        controller.close()
        self.assertEqual(connection.events[-5:], [
            ("command", 7, 1505), ("command", 8, 1460),
            ("command", 9, 1370), ("command", 10, 1200),
            ("close",)])

    def test_diagonal_request_scales_both_axes_to_saved_limits(self):
        decision = decide((0, 0), (640, 480), max_tested_us=400)
        pulses = bounded_pulses_for(decision, expected_settings())
        self.assertTrue(all(expected_settings()[ch]["min"] <= pwm <=
                            expected_settings()[ch]["max"]
                            for ch, pwm in pulses.items()))
        requested_x = abs(decision.safe_nose_x_us)
        requested_y = abs(decision.safe_nose_y_us)
        applied_x = abs(pulses[8] - NEUTRAL[8])
        applied_y = abs(pulses[7] - NEUTRAL[7])
        self.assertAlmostEqual(applied_x / requested_x,
                               applied_y / requested_y, delta=0.01)

    def test_cardinal_outer_zone_reaches_full_400_offset(self):
        horizontal = bounded_pulses_for(
            decide((639, 240), (640, 480), max_tested_us=400),
            expected_settings())
        vertical = bounded_pulses_for(
            decide((320, 0), (640, 480), max_tested_us=400),
            expected_settings())
        self.assertEqual(horizontal[8], NEUTRAL[8] - 400)
        self.assertEqual(horizontal[9], NEUTRAL[9] + 400)
        self.assertEqual(vertical[7], NEUTRAL[7] + 400)
        self.assertEqual(vertical[10], NEUTRAL[10] - 400)


if __name__ == "__main__":
    unittest.main()
