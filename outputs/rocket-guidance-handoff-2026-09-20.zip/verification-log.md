# Always-on pad guidance verification log

Plan: `docs/superpowers/plans/2026-09-20-always-on-pad-guidance.md`

- Task 1, 2026-09-20: `python -m unittest discover -s tests -v` — 39 tests passed.
- Task 2, 2026-09-20: `python -m unittest discover -s tests -v` — 48 tests passed.

## 2026-09-20 native autonomous guidance

- Corrected the saved tested endpoints to S7 1105/1505/1905, S8 1060/1460/1860, S9 970/1370/1770, and S10 800/1200/1600.
- `python -m unittest discover -s tests -v` after Task 3: 55 tests, OK.
- Full cardinal outer-zone test proves an actual 400 us offset from each calibrated neutral.
- `python -m unittest tests.test_guidance_web tests.test_live_camera_bench tests.test_camera_zone_preview tests.test_autonomous_guidance -v` after Task 4: 17 tests, OK.
- `python -m unittest discover -s tests -v` after boot-service packaging: 64 tests, OK.
- Observe-only defaults retain `GUIDANCE_MAX_OFFSET=400` while forcing neutral hardware commands.
